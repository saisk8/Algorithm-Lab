
When the first element is considered as the pivot

File name: in_ran100.txt     , Input Size: 100   , Number of Swaps = 160     , Number of Comparisons = 605         
File name: in_ran1000.txt    , Input Size: 1000  , Number of Swaps = 2387    , Number of Comparisons = 10708       
File name: in_ran10000.txt   , Input Size: 10000 , Number of Swaps = 31694   , Number of Comparisons = 147332      
File name: in_ran100000.txt  , Input Size: 100000, Number of Swaps = 391668  , Number of Comparisons = 1987354     
File name: in_asec100.txt    , Input Size: 100   , Number of Swaps = 83      , Number of Comparisons = 3977        
File name: in_asec1000.txt   , Input Size: 1000  , Number of Swaps = 824     , Number of Comparisons = 386637      
File name: in_asec10000.txt  , Input Size: 10000 , Number of Swaps = 8195    , Number of Comparisons = 39288789    
File name: in_asec100000.txt , Input Size: 100000, Number of Swaps = 81847   , Number of Comparisons = 3932593328  
File name: in_desc100.txt    , Input Size: 100   , Number of Swaps = 95      , Number of Comparisons = 4028        
File name: in_desc1000.txt   , Input Size: 1000  , Number of Swaps = 941     , Number of Comparisons = 391662      
File name: in_desc10000.txt  , Input Size: 10000 , Number of Swaps = 9438    , Number of Comparisons = 40330322    
File name: in_desc100000.txt , Input Size: 100000, Number of Swaps = 94240   , Number of Comparisons = 4030770326  

When a random element is considered as the pivot

File name: in_ran100.txt     , Input Size: 100   , Number of Swaps = 230     , Number of Comparisons = 563         
File name: in_ran1000.txt    , Input Size: 1000  , Number of Swaps = 3083    , Number of Comparisons = 10435       
File name: in_ran10000.txt   , Input Size: 10000 , Number of Swaps = 38061   , Number of Comparisons = 156759      
File name: in_ran100000.txt  , Input Size: 100000, Number of Swaps = 457800  , Number of Comparisons = 2015845     
File name: in_asec100.txt    , Input Size: 100   , Number of Swaps = 120     , Number of Comparisons = 636         
File name: in_asec1000.txt   , Input Size: 1000  , Number of Swaps = 1204    , Number of Comparisons = 10822       
File name: in_asec10000.txt  , Input Size: 10000 , Number of Swaps = 12062   , Number of Comparisons = 158872      
File name: in_asec100000.txt , Input Size: 100000, Number of Swaps = 120689  , Number of Comparisons = 2065317     
File name: in_desc100.txt    , Input Size: 100   , Number of Swaps = 185     , Number of Comparisons = 623         
File name: in_desc1000.txt   , Input Size: 1000  , Number of Swaps = 1847    , Number of Comparisons = 10069       
File name: in_desc10000.txt  , Input Size: 10000 , Number of Swaps = 18555   , Number of Comparisons = 153179      
File name: in_desc100000.txt , Input Size: 100000, Number of Swaps = 187722  , Number of Comparisons = 2127243     
